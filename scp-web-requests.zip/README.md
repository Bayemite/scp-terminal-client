# scp-terminal-client

why is this side project more almost complete than MY MAIN PROJECT

That was supposed to be ironic humor

And so was that

And so was that
