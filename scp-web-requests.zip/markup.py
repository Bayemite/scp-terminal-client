# Custom tags that are handled seperately from Rich
class tag:
    rule = "[rule]"
    center = "[center]" # Current line till end should be centered
    

